import{W as n}from"./index-C0gi1F0x.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
