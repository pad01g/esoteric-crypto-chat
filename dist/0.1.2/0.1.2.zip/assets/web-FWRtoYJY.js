import{W as n}from"./index-BB41EhEB.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
