import{W as n}from"./index-CRi7eUih.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
