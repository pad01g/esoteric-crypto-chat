import{W as n}from"./index-Dqws2jMK.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
