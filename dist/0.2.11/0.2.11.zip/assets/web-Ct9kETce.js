import{W as n}from"./index-Nv35iuSq.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
