import{W as n}from"./index-CsiWEX-D.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
