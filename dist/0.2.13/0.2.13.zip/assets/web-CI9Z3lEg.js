import{W as n}from"./index-CxMC_H0i.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
