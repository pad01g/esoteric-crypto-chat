import{W as n}from"./index-C-98H3s4.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
