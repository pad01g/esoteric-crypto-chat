import{W as n}from"./index-BHuSMCcM.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
