import{W as n}from"./index-DN-H5xec.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
