import{W as n}from"./index-D8hBCv5R.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
